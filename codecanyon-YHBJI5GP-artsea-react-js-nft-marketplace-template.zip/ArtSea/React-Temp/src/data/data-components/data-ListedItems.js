import {

	// ListedItems
	ListedItemsArtwork1,
	ListedItemsArtwork2,
	ListedItemsArtwork3,
	ListedItemsArtwork4,
	ListedItemsArtwork5,
	ListedItemsArtwork6,
	ListedItemsArtwork7,
	ListedItemsArtwork8,
	ListedItemsAuthors2,
	ListedItemsAuthors3,
	ListedItemsAuthors8,
	ListedItemsAuthors6,


} from '../../utils/allImgs'

export const ListedItemsData = [
	{
		imgBig:ListedItemsArtwork1,
		imgSm:ListedItemsAuthors2,
		title:'@Smith Wright',
		price:0.081,
		bid:0.081,
	},
	{
		imgBig:ListedItemsArtwork2,
		imgSm:ListedItemsAuthors3,
		title:'@Smith Wright',
		price:0.081,
		bid:0.081,
	},
	{
		imgBig:ListedItemsArtwork3,
		imgSm:ListedItemsAuthors8,
		title:'@Smith Wright',
		price:0.081,
		bid:0.081,
	},
	{
		imgBig:ListedItemsArtwork4,
		imgSm:ListedItemsAuthors6,
		title:'@Smith Wright',
		price:0.081,
		bid:0.081,
	},
	{
		imgBig:ListedItemsArtwork5,
		imgSm:ListedItemsAuthors2,
		title:'@Smith Wright',
		price:0.081,
		bid:0.081,
	},
	{
		imgBig:ListedItemsArtwork6,
		imgSm:ListedItemsAuthors3,
		title:'@Smith Wright',
		price:0.081,
		bid:0.081,
	},
	{
		imgBig:ListedItemsArtwork7,
		imgSm:ListedItemsAuthors8,
		title:'@Smith Wright',
		price:0.081,
		bid:0.081,
	},
	{
		imgBig:ListedItemsArtwork8,
		imgSm:ListedItemsAuthors6,
		title:'@Smith Wright',
		price:0.081,
		bid:0.081,
	},
]

// export {data1 , data2 , data3}