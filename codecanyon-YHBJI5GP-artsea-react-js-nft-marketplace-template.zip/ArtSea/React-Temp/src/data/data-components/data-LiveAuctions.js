import {

	// LiveAuctions component
	LiveAuctionsArtwork9,
	LiveAuctionsAuthors2,
	LiveAuctionsArtwork1,
	LiveAuctionsAuthors3,
	LiveAuctionsArtwork11,
	LiveAuctionsAuthors8,
	LiveAuctionsArtwork2,
	LiveAuctionsAuthors6,


} from '../../utils/allImgs'

export const LiveAuctionsData = [
	{
		imgBig:LiveAuctionsArtwork9,
		imgSm:LiveAuctionsAuthors2,
		title:'@Amillia Nnor',
		text:'Bored Ape Yacht Club'
	},
	{
		imgBig:LiveAuctionsArtwork1,
		imgSm:LiveAuctionsAuthors3,
		title:'@Johan Done',
		text:'After Snow: Attraction'
	},
	{
		imgBig:LiveAuctionsArtwork11,
		imgSm:LiveAuctionsAuthors8,
		title:'@LarySmith-3',
		text:'Mortimer Crypto Mystic'
	},
	{
		imgBig:LiveAuctionsArtwork2,
		imgSm:LiveAuctionsAuthors6,
		title:'@SmithWright',
		text:'People are the pillars'
	}
]

// export {data1 , data2 , data3}