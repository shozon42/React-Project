import {

	// Profile Component
	ProfileArtwork1,
	ProfileArtwork2,
	ProfileArtwork3,
	ProfileArtwork4,
	ProfileArtwork5,
	ProfileArtwork6,
	ProfileAuthors2,
	ProfileAuthors3,
	ProfileAuthors8,

} from '../../utils/allImgs'

export const ProfileData = [
	{	
		ClassChange:'branding',
		imgBig:ProfileArtwork1,
		imgSm:ProfileAuthors2,
		title:'@Smith Wright',
		price:0.081,
		bid:0.081,
	},
	{	
		ClassChange:'design',
		imgBig:ProfileArtwork2,
		imgSm:ProfileAuthors3,
		title:'@Smith Wright',
		price:0.081,
		bid:0.081,
	},
	{	
		ClassChange:'development',
		imgBig:ProfileArtwork3,
		imgSm:ProfileAuthors8,
		title:'@Smith Wright',
		price:0.081,
		bid:0.081,
	},
	{	
		ClassChange:'branding',
		imgBig:ProfileArtwork4,
		imgSm:ProfileAuthors2,
		title:'@Smith Wright',
		price:0.081,
		bid:0.081,
	},
	{	
		ClassChange:'design',
		imgBig:ProfileArtwork5,
		imgSm:ProfileAuthors3,
		title:'@Smith Wright',
		price:0.081,
		bid:0.081,
	},
	{	
		ClassChange:'development',
		imgBig:ProfileArtwork6,
		imgSm:ProfileAuthors8,
		title:'@Smith Wright',
		price:0.081,
		bid:0.081,
	}
]
// export {data1 , data2 , data3}